$(document).ready(function() {
    $(".owl-carousel").owlCarousel();
});

// var owl = $('.owl-carousel');
// owl.owlCarousel({
//     items: 3,
//     loop: true,
//     // margin: 10,
//     autoplay: true,
//     // autoplayTimeout: 1500,
//     autoplayHoverPause: true
// });
// $('.play').on('click', function() {
//     owl.trigger('play.owl.autoplay', [500])
// })
// $('.stop').on('click', function() {
//     owl.trigger('stop.owl.autoplay')
// })
var owl = $('.owl-carousel');
owl.owlCarousel({
    items: 3, // change items to 1
    loop: true,
    autoplay: true,
    autoplayTimeout: 3000,
    autoplayHoverPause: true,
    responsive: {
        // add responsive settings for mobile devices
        0: {
            items: 1,
            // stagePadding: 20,
            margin: 30
        },
        767: {
            items: 1,
            // stagePadding: 30,
            margin: 30
        },
        768: {
            items: 3,
            // stagePadding: 40,
            margin: 20,
        },
        1024: {
            items: 3,
            margin: 30
        }
    }
});
$('.play').on('click', function() {
    owl.trigger('play.owl.autoplay', [100])
})
$('.stop').on('click', function() {
    owl.trigger('stop.owl.autoplay')
})